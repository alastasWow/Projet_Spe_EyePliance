Le fichier LBPHface.yml doit être généré par l'utilisateur
Ce fichier correspond à notre propre exécution.
